let totalAsistentes = 0;

const nombreInput = document.getElementById("nombre");
const profesionInput = document.getElementById("profesion");
const boton = document.getElementById("btnRegistrar");
const lista = document.getElementById("listaAsistentes");
const contador = document.getElementById("contador");

boton.addEventListener("click", function () {

    const nombre = nombreInput.value.trim();
    const profesion = profesionInput.value.trim();

    if (nombre === "" || profesion === "") {
        alert("Faltan datos por completar");
        return;
    }

    const nuevoElemento = document.createElement("li");

    nuevoElemento.textContent =
        nombre + " - " + profesion;

    lista.appendChild(nuevoElemento);

    totalAsistentes++;

    contador.textContent =
        "Total asistentes: " + totalAsistentes;

    nombreInput.value = "";
    profesionInput.value = "";
});